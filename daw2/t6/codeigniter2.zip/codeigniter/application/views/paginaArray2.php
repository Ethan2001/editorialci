<?php
    //$array=array('nombre'=>'ludwing','apellido'=>'salinas');
    foreach($datos as $dato){
        echo $dato ." ";
    }
?>