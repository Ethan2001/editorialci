<div id="container">


<form action="<?=base_url()?>ciudades/crearpost" method="post">

<label for="nombre">nombre</label>
<input input="text" id="nombre" name="nombre">
<input type="submit">

</form>

</div>