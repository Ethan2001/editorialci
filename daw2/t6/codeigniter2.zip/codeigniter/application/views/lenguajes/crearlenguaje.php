<div class="container">
<h2>
Introduce el nombre del lenguaje</h2>
<form action="<?=base_url()?>lenguajes/crearpost" method="post" class="form">
<div class="form-group">
<label for="nombre">Nombre</label>
<input id="nombre" type="text" name="nombre">
</div>


<input type="submit">
</form>
</div>