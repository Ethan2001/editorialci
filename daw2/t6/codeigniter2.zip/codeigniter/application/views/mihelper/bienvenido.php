<body>
<h1>hola</h1>
<?= getNombre() ?>

</body>