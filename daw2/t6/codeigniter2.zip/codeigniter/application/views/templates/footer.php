<?php ?>
<footer class="container">
mini aplicacion

</footer>
