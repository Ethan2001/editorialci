<nav class="container navbar navbar-inverse">
  <div class="navbar-header">
    <a class="navbar-brand" href="<?=base_url()?>">Empleados</a>
  </div>
  <div class="collapse navbar-collapse" id="myNavbar">
    <ul class="nav navbar-nav">
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
           empleados<span class="caret"></span>
        </a>
	<ul class="dropdown-menu">
  <li class="dropdown-header">BEAN 1</li>
	  <li><a href="<?=base_url()?>empleados/crear">crear</a>
	  
	  </li>
          <li role="separator" class="divider"></li>
          
           <!-- M�s beans y m�s acciones -->


        </ul>
      </li>
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
           ciudades<span class="caret"></span>
        </a>
	<ul class="dropdown-menu">
  <li class="dropdown-header">BEAN 1</li>
	  <li><a href="<?=base_url()?>ciudad/crear">crear</a>
	  
	  </li>
	  <li><a href="<?=base_url()?>ciudad/listar">listar</a>
	  
	  </li>
          <li role="separator" class="divider"></li>
          
           <!-- M�s beans y m�s acciones -->


        </ul>
      </li>
      
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
          lenguajes de programacion<span class="caret"></span>
        </a>
	<ul class="dropdown-menu">
  <li class="dropdown-header">BEAN 1</li>
	  <li><a href="<?=base_url()?>lenguajes/crear ">crear</a>
	  
	  </li>
	  <li><a href="<?=base_url()?>lenguajes/listar">listar</a>
	  
	  </li>
          <li role="separator" class="divider"></li>
          
           <!-- M�s beans y m�s acciones -->


        </ul>
      </li>
      
      
      
      
      
      
      
      
      

      <!-- M�s men�s -->

    </ul>
  </div>
</nav>


