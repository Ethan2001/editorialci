<?php ?>
<body>
nombre <input type='text' id='nombre' name="nombre">
contrase�a <input type='text' id='contrasena' name="contrasena">
</body>