<h1>hol usuario</h1>
<form action="saludar/post" method="get">
<input type="text" name="nombre"><br/>
	<input type="text" name="apellido"><br/>
	<input type="submit">
</form>
<a href="saludo/adios">Y para despedirnos...</a>